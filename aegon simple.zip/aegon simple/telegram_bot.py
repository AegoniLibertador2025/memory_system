"""
Bot de Telegram para AEGON Simple V2
Permite solo usuarios autorizados y gestiona comandos específicos
"""
from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes
from telegram.error import TelegramError
import logging
import json
from typing import List, Dict, Any, Optional
from pathlib import Path
import asyncio

# Importar módulos del sistema
from memory_module import get_memory_manager
from scanner_module import get_code_scanner
from llm_module import get_llm_interface

# Configurar logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)


class AegonTelegramBot:
    """Bot de Telegram con funcionalidades específicas"""
    
    def __init__(self, 
                 bot_token: str, 
                 openai_api_key: str,
                 allowed_users: List[str],
                 default_model: str = "gpt-3.5-turbo"):
        
        self.bot_token = bot_token
        self.allowed_users = set(str(user_id) for user_id in allowed_users)
        
        # Inicializar módulos
        self.memory = get_memory_manager()
        self.scanner = get_code_scanner()
        self.llm = get_llm_interface(openai_api_key, default_model)
        
        # Aplicación del bot
        self.application = Application.builder().token(bot_token).build()
        
        # Configurar handlers
        self._setup_handlers()
    
    def _setup_handlers(self):
        """Configura los handlers de comandos y mensajes"""
        # Comandos
        self.application.add_handler(CommandHandler("start", self.start_command))
        self.application.add_handler(CommandHandler("help", self.help_command))
        self.application.add_handler(CommandHandler("scan", self.scan_command))
        self.application.add_handler(CommandHandler("analyze", self.analyze_command))
        self.application.add_handler(CommandHandler("modify", self.modify_command))
        self.application.add_handler(CommandHandler("memory", self.memory_command))
        self.application.add_handler(CommandHandler("chat", self.chat_command))
        
        # Mensajes normales
        self.application.add_handler(
            MessageHandler(filters.TEXT & ~filters.COMMAND, self.handle_message)
        )
        
        # Error handler
        self.application.add_error_handler(self.error_handler)
    
    def is_authorized(self, user_id: str) -> bool:
        """Verifica si el usuario está autorizado"""
        return str(user_id) in self.allowed_users
    
    async def start_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Comando /start"""
        user_id = str(update.effective_user.id)
        
        if not self.is_authorized(user_id):
            await update.message.reply_text("🚫 Usuario no autorizado.")
            return
        
        welcome_message = """
🤖 **AEGON Simple V2** - Bot de IA Activado

**Comandos disponibles:**
- `/help` - Muestra esta ayuda
- `/scan` - Escanea directorio actual
- `/analyze <archivo>` - Analiza archivo Python
- `/modify <archivo> <código>` - Modifica archivo
- `/memory <key> [value]` - Gestiona memoria
- `/chat <mensaje>` - Chat con IA

También puedes enviar mensajes normales para chat.
        """
        
        await update.message.reply_text(welcome_message, parse_mode='Markdown')
    
    async def help_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Comando /help"""
        if not self.is_authorized(str(update.effective_user.id)):
            await update.message.reply_text("🚫 Usuario no autorizado.")
            return
        
        help_text = """
**📚 AYUDA DE AEGON SIMPLE V2**

**🔍 Comandos de Escaneo:**
• `/scan` - Escanea archivos .py en directorio actual
• `/analyze archivo.py` - Analiza un archivo específico

**🛠 Comandos de Modificación:**
• `/modify archivo.py codigo` - Modifica un archivo
  Ejemplo: `/modify test.py print("Hola mundo")`

**💾 Comandos de Memoria:**
• `/memory key` - Lee valor de memoria
• `/memory key value` - Guarda en memoria
• `/memory` - Lista todas las claves

**💬 Comandos de Chat:**
• `/chat mensaje` - Chat con IA
• También puedes enviar mensajes directos

**Nota:** Todos los archivos se respaldan antes de modificar.
        """
        
        await update.message.reply_text(help_text, parse_mode='Markdown')
    
    async def scan_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Comando /scan"""
        if not self.is_authorized(str(update.effective_user.id)):
            await update.message.reply_text("🚫 Usuario no autorizado.")
            return
        
        await update.message.reply_text("🔍 Escaneando archivos Python...")
        
        try:
            files = self.scanner.scan_directory()
            
            if not files:
                await update.message.reply_text("No se encontraron archivos Python.")
                return
            
            # Formatear resultados
            response = "📁 **Archivos encontrados:**\n\n"
            for i, file in enumerate(files[:10], 1):  # Limitar a 10 archivos
                response += f"{i}. **{file.name}**\n"
                response += f"   - Líneas: {file.lines}\n"
                response += f"   - Funciones: {len(file.functions)}\n"
                response += f"   - Clases: {len(file.classes)}\n"
                response += f"   - Complejidad: {file.complexity_score:.1f}\n\n"
            
            if len(files) > 10:
                response += f"... y {len(files) - 10} archivos más\n"
            
            await update.message.reply_text(response, parse_mode='Markdown')
            
        except Exception as e:
            await update.message.reply_text(f"❌ Error: {str(e)}")
    
    async def analyze_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Comando /analyze"""
        if not self.is_authorized(str(update.effective_user.id)):
            await update.message.reply_text("🚫 Usuario no autorizado.")
            return
        
        if not context.args:
            await update.message.reply_text("❌ Uso: `/analyze archivo.py`")
            return
        
        filename = context.args[0]
        
        try:
            analysis = self.scanner.analyze_file(filename)
            
            if not analysis:
                await update.message.reply_text(f"❌ No se pudo analizar: {filename}")
                return
            
            if analysis.errors:
                await update.message.reply_text(f"❌ Errores: {analysis.errors}")
                return
            
            response = f"📊 **Análisis de {analysis.name}**\n\n"
            response += f"**Estadísticas:**\n"
            response += f"• Líneas: {analysis.lines}\n"
            response += f"• Tamaño: {analysis.size} bytes\n"
            response += f"• Complejidad: {analysis.complexity_score}\n\n"
            
            response += f"**Imports:** {len(analysis.imports)}\n"
            for imp in analysis.imports[:5]:  # Primeros 5
                response += f"• {imp}\n"
            
            response += f"\n**Funciones:** {len(analysis.functions)}\n"
            for func in analysis.functions[:5]:  # Primeras 5
                response += f"• {func}\n"
            
            response += f"\n**Clases:** {len(analysis.classes)}\n"
            for cls in analysis.classes[:5]:  # Primeras 5
                response += f"• {cls}\n"
            
            await update.message.reply_text(response, parse_mode='Markdown')
            
        except Exception as e:
            await update.message.reply_text(f"❌ Error: {str(e)}")
    
    async def modify_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Comando /modify"""
        if not self.is_authorized(str(update.effective_user.id)):
            await update.message.reply_text("🚫 Usuario no autorizado.")
            return
        
        if len(context.args) < 2:
            await update.message.reply_text("❌ Uso: `/modify archivo.py codigo`")
            return
        
        filename = context.args[0]
        code = " ".join(context.args[1:])
        
        try:
            # Verificar que el archivo existe
            if not Path(filename).exists():
                await update.message.reply_text(f"❌ Archivo no encontrado: {filename}")
                return
            
            await update.message.reply_text(f"🔄 Modificando {filename}...")
            
            # Crear backup y modificar
            result = self.scanner.modify_file(filename, code)
            
            if result["success"]:
                response = f"✅ **Archivo modificado con éxito**\n\n"
                response += f"• Archivo: {filename}\n"
                response += f"• Backup: {result['backup_path']}\n"
                
                # Analizar el archivo modificado
                analysis = self.scanner.analyze_file(filename)
                if analysis and not analysis.errors:
                    response += f"• Nuevas líneas: {analysis.lines}\n"
                    response += f"• Nueva complejidad: {analysis.complexity_score}\n"
                
                await update.message.reply_text(response, parse_mode='Markdown')
            else:
                await update.message.reply_text(f"❌ Error: {result['error']}")
        
        except Exception as e:
            await update.message.reply_text(f"❌ Error: {str(e)}")
    
    async def memory_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Comando /memory"""
        if not self.is_authorized(str(update.effective_user.id)):
            await update.message.reply_text("🚫 Usuario no autorizado.")
            return
        
        args = context.args
        
        try:
            if not args:
                # Listar todas las claves
                keys = self.memory.list_knowledge_keys()
                if not keys:
                    await update.message.reply_text("📭 No hay datos en memoria.")
                    return
                
                response = "📚 **Claves en memoria:**\n\n"
                for key in keys[:20]:  # Limitar a 20
                    response += f"• `{key}`\n"
                
                if len(keys) > 20:
                    response += f"\n... y {len(keys) - 20} más"
                
                await update.message.reply_text(response, parse_mode='Markdown')
                
            elif len(args) == 1:
                # Leer valor
                key = args[0]
                value = self.memory.get_knowledge(key)
                
                if value is None:
                    await update.message.reply_text(f"❌ Clave '{key}' no encontrada.")
                else:
                    response = f"📖 **Valor de '{key}':**\n\n"
                    # Truncar si es muy largo
                    value_str = str(value)
                    if len(value_str) > 500:
                        value_str = value_str[:500] + "..."
                    response += f"`{value_str}`"
                    await update.message.reply_text(response, parse_mode='Markdown')
            
            else:
                # Guardar valor
                key = args[0]
                value = " ".join(args[1:])
                
                self.memory.save_knowledge(key, value)
                await update.message.reply_text(
                    f"✅ Guardado: `{key}` = `{value}`", 
                    parse_mode='Markdown'
                )
        
        except Exception as e:
            await update.message.reply_text(f"❌ Error: {str(e)}")
    
    async def chat_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Comando /chat"""
        if not self.is_authorized(str(update.effective_user.id)):
            await update.message.reply_text("🚫 Usuario no autorizado.")
            return
        
        if not context.args:
            await update.message.reply_text("❌ Uso: `/chat mensaje`")
            return
        
        message = " ".join(context.args)
        await self._process_chat_message(update, message)
    
    async def handle_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Maneja mensajes normales (sin comando)"""
        if not self.is_authorized(str(update.effective_user.id)):
            await update.message.reply_text("🚫 Usuario no autorizado.")
            return
        
        message = update.message.text
        await self._process_chat_message(update, message)
    
    async def _process_chat_message(self, update: Update, message: str):
        """Procesa mensaje de chat con IA"""
        user_id = str(update.effective_user.id)
        
        try:
            await update.message.reply_text("🤔 Pensando...")
            
            # Obtener respuesta del LLM
            response = self.llm.chat(message, include_history=True)
            
            if response.error:
                await update.message.reply_text(f"❌ Error: {response.error}")
                return
            
            # Guardar conversación en memoria
            self.memory.save_conversation(user_id, message, response.message)
            
            # Formatear respuesta
            reply_text = f"🤖 **AEGON:**\n\n{response.message}\n\n"
            reply_text += f"_Tokens: {response.tokens_used} | Costo: ${response.cost_estimate:.4f}_"
            
            await update.message.reply_text(reply_text, parse_mode='Markdown')
            
        except Exception as e:
            await update.message.reply_text(f"❌ Error procesando mensaje: {str(e)}")
            logger.error(f"Error en chat: {e}")
    
    async def error_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Maneja errores del bot"""
        logger.error(f"Error: {context.error}")
        
        if update.effective_message:
            await update.effective_message.reply_text(
                "❌ Ocurrió un error. Por favor, intenta nuevamente."
            )
    
    def run(self):
        """Ejecuta el bot"""
        logger.info("Iniciando bot AEGON Simple V2...")
        
        try:
            self.application.run_polling()
        except Exception as e:
            logger.error(f"Error ejecutando bot: {e}")
            raise
    
    def stop(self):
        """Detiene el bot graciosamente"""
        if self.application:
            self.application.stop()


# Función para crear instancia del bot
def create_bot(bot_token: str, 
               openai_api_key: str, 
               allowed_users: List[str],
               default_model: str = "gpt-3.5-turbo") -> AegonTelegramBot:
    """Crear instancia del bot con configuración"""
    return AegonTelegramBot(bot_token, openai_api_key, allowed_users, default_model)


if __name__ == "__main__":
    # Test básico - configuración desde variables de entorno
    import os
    
    bot_token = os.getenv("TELEGRAM_BOT_TOKEN", "tu-token-aqui")
    openai_key = os.getenv("OPENAI_API_KEY", "tu-api-key-aqui")
    allowed_users = ["7526454163"]  # Reemplazar con IDs autorizados
    
    if bot_token != "tu-token-aqui" and openai_key != "tu-api-key-aqui":
        bot = create_bot(bot_token, openai_key, allowed_users)
        bot.run()
    else:
        print("Configura TELEGRAM_BOT_TOKEN y OPENAI_API_KEY antes de ejecutar")

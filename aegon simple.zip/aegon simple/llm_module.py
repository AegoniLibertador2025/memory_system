from openai import OpenAI
from typing import List, Dict, Optional, Any
from dataclasses import dataclass
import json
import time
from datetime import datetime

@dataclass
class ChatMessage:
    role: str
    content: str
    timestamp: Optional[str] = None

@dataclass
class ChatResponse:
    message: str
    model: str
    tokens_used: int
    cost_estimate: float
    timestamp: str
    error: Optional[str] = None

class LLMInterface:
    PRICING = {
        "gpt-3.5-turbo": {"input": 0.003, "output": 0.006},
        "gpt-4o": {"input": 0.03, "output": 0.06}
    }
    SUPPORTED_MODELS = ["gpt-3.5-turbo", "gpt-4o"]

    def __init__(self, api_key: str, default_model: str = "gpt-3.5-turbo"):
        if default_model not in self.SUPPORTED_MODELS:
            raise ValueError(f"Model {default_model} not supported. Use: {self.SUPPORTED_MODELS}")
        self.api_key = api_key
        self.default_model = default_model
        self.client = OpenAI(api_key=api_key)
        self.conversation_history: List[ChatMessage] = []
        self.default_params = {"temperature": 0.7, "max_tokens": 1500, "top_p": 1.0, "frequency_penalty": 0.0, "presence_penalty": 0.0}

    def chat(self, message: str, model: Optional[str] = None, system_prompt: Optional[str] = None, include_history: bool = False, **kwargs) -> ChatResponse:
        model = model or self.default_model
        messages = [{"role": "system", "content": system_prompt}] if system_prompt else []
        if include_history:
            messages.extend({"role": msg.role, "content": msg.content} for msg in self.conversation_history)
        messages.append({"role": "user", "content": message})
        params = {**self.default_params, **kwargs}
        try:
            response = self.client.chat.completions.create(model=model, messages=messages, **params)
            response_message = response.choices[0].message.content
            tokens_used = response.usage.total_tokens
            cost = self._estimate_cost(model, response.usage.prompt_tokens, response.usage.completion_tokens)
            self.conversation_history.extend([ChatMessage("user", message), ChatMessage("assistant", response_message)])
            return ChatResponse(message=response_message, model=model, tokens_used=tokens_used, cost_estimate=cost, timestamp=datetime.now().isoformat())
        except Exception as e:
            return ChatResponse(message="", model=model, tokens_used=0, cost_estimate=0.0, timestamp=datetime.now().isoformat(), error=str(e))

    def _estimate_cost(self, model: str, input_tokens: int, output_tokens: int) -> float:
        if model not in self.PRICING:
            return 0.0
        pricing = self.PRICING[model]
        return (input_tokens / 1000) * pricing["input"] + (output_tokens / 1000) * pricing["output"]

    def set_system_prompt(self, prompt: str) -> None:
        self.conversation_history = [msg for msg in self.conversation_history if msg.role != "system"]
        self.conversation_history.insert(0, ChatMessage("system", prompt, datetime.now().isoformat()))

    def clear_history(self) -> None:
        self.conversation_history = []

    def get_history(self, last_n: Optional[int] = None) -> List[Dict[str, str]]:
        history = self.conversation_history[-last_n:] if last_n else self.conversation_history
        return [{"role": msg.role, "content": msg.content, "timestamp": msg.timestamp} for msg in history]

    def save_conversation(self, filepath: str) -> None:
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump({"model": self.default_model, "timestamp": datetime.now().isoformat(), "messages": self.get_history()}, f, indent=2, ensure_ascii=False)

    def load_conversation(self, filepath: str) -> None:
        with open(filepath, 'r', encoding='utf-8') as f:
            data = json.load(f)
        self.conversation_history = [ChatMessage(**msg) for msg in data["messages"]]

    def get_conversation_stats(self) -> Dict[str, Any]:
        stats = {"total_messages": len(self.conversation_history), "user_messages": sum(1 for m in self.conversation_history if m.role == "user"),
                 "assistant_messages": sum(1 for m in self.conversation_history if m.role == "assistant"), "system_messages": sum(1 for m in self.conversation_history if m.role == "system"),
                 "total_characters": sum(len(m.content) for m in self.conversation_history), "average_message_length": 0}
        if stats["total_messages"] > 0:
            stats["average_message_length"] = stats["total_characters"] / stats["total_messages"]
        return stats

    def get_last_response(self) -> Optional[ChatResponse]:
        for msg in reversed(self.conversation_history):
            if msg.role == "assistant":
                return ChatResponse(message=msg.content, model=self.default_model, tokens_used=0, cost_estimate=0.0, timestamp=msg.timestamp)
        return None

    def set_default_params(self, **params) -> None:
        self.default_params.update(params)

    def quick_response(self, prompt: str, model: Optional[str] = None) -> str:
        response = self.chat(prompt, model=model, include_history=False)
        return f"Error: {response.error}" if response.error else response.message

    def calculate_total_cost(self) -> float:
        total_chars = sum(len(m.content) for m in self.conversation_history)
        est_tokens = total_chars / 4
        return self._estimate_cost(self.default_model, est_tokens, est_tokens)

def get_llm_interface(api_key: str, model: str = "gpt-3.5-turbo") -> LLMInterface:
    return LLMInterface(api_key, model)

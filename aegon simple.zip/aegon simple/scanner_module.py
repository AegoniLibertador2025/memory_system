"""
Módulo Auto Scanner y Code Modifier para AEGON Simple V2
Escanea carpetas, analiza archivos Python y permite modificaciones
"""
import os
import re
import ast
import shutil
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Optional, Any, Union
from dataclasses import dataclass, asdict


@dataclass
class FileAnalysis:
    """Estructura para almacenar análisis de archivo"""
    path: str
    name: str
    size: int
    lines: int
    imports: List[str]
    functions: List[str]
    classes: List[str]
    complexity_score: float
    last_modified: str
    errors: List[str]


class CodeScanner:
    """Scanner de código Python con análisis y modificación"""
    
    def __init__(self, base_path: str = "."):
        self.base_path = Path(base_path)
        self.backup_dir = self.base_path / "code_backups"
        self.backup_dir.mkdir(exist_ok=True)
    
    def scan_directory(self, directory: str = None) -> List[FileAnalysis]:
        """Escanea directorio en busca de archivos .py"""
        scan_path = Path(directory) if directory else self.base_path
        python_files = []
        
        for file_path in scan_path.rglob("*.py"):
            if file_path.is_file():
                analysis = self.analyze_file(str(file_path))
                if analysis:
                    python_files.append(analysis)
        
        return python_files
    
    def analyze_file(self, file_path: str) -> Optional[FileAnalysis]:
        """Analiza un archivo Python específico"""
        path = Path(file_path)
        
        if not path.exists() or not path.suffix == ".py":
            return None
        
        try:
            with open(path, 'r', encoding='utf-8') as file:
                content = file.read()
            
            # Información básica
            stats = path.stat()
            lines = len(content.splitlines())
            
            # Parsea el AST
            tree = ast.parse(content)
            
            # Extrae información
            imports = self._extract_imports(tree)
            functions = self._extract_functions(tree)
            classes = self._extract_classes(tree)
            complexity = self._calculate_complexity(tree)
            
            return FileAnalysis(
                path=str(path),
                name=path.name,
                size=stats.st_size,
                lines=lines,
                imports=imports,
                functions=functions,
                classes=classes,
                complexity_score=complexity,
                last_modified=datetime.fromtimestamp(stats.st_mtime).isoformat(),
                errors=[]
            )
            
        except Exception as e:
            return FileAnalysis(
                path=str(path),
                name=path.name,
                size=0,
                lines=0,
                imports=[],
                functions=[],
                classes=[],
                complexity_score=0.0,
                last_modified="",
                errors=[str(e)]
            )
    
    def _extract_imports(self, tree: ast.AST) -> List[str]:
        """Extrae imports del AST"""
        imports = []
        
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    imports.append(alias.name)
            elif isinstance(node, ast.ImportFrom):
                module = node.module or ""
                for alias in node.names:
                    imports.append(f"from {module} import {alias.name}")
        
        return imports
    
    def _extract_functions(self, tree: ast.AST) -> List[str]:
        """Extrae funciones del AST"""
        functions = []
        
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef):
                # Incluye información de argumentos
                args = []
                for arg in node.args.args:
                    if arg.arg != "self":
                        args.append(arg.arg)
                
                func_signature = f"{node.name}({', '.join(args)})"
                functions.append(func_signature)
        
        return functions
    
    def _extract_classes(self, tree: ast.AST) -> List[str]:
        """Extrae clases del AST"""
        classes = []
        
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef):
                # Incluye herencia
                bases = []
                for base in node.bases:
                    if isinstance(base, ast.Name):
                        bases.append(base.id)
                
                class_info = node.name
                if bases:
                    class_info += f"({', '.join(bases)})"
                
                classes.append(class_info)
        
        return classes
    
    def _calculate_complexity(self, tree: ast.AST) -> float:
        """Calcula un score simple de complejidad"""
        complexity = 0
        
        for node in ast.walk(tree):
            # Estructura de control
            if isinstance(node, (ast.If, ast.For, ast.While, ast.Try, ast.With)):
                complexity += 1
            # Funciones anidadas
            elif isinstance(node, ast.FunctionDef):
                complexity += 0.5
            # Expresiones lambda
            elif isinstance(node, ast.Lambda):
                complexity += 0.25
        
        return complexity
    
    def create_backup(self, file_path: str) -> str:
        """Crea un backup del archivo antes de modificarlo"""
        path = Path(file_path)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_name = f"{path.stem}_{timestamp}{path.suffix}"
        backup_path = self.backup_dir / backup_name
        
        shutil.copy2(path, backup_path)
        return str(backup_path)
    
    def modify_file(self, file_path: str, new_content: str, create_backup: bool = True) -> Dict[str, Any]:
        """Modifica un archivo Python con backup automático"""
        path = Path(file_path)
        
        if not path.exists():
            return {"success": False, "error": "File not found"}
        
        result = {"success": True, "backup_path": None, "error": None}
        
        try:
            # Crear backup
            if create_backup:
                backup_path = self.create_backup(file_path)
                result["backup_path"] = backup_path
            
            # Validar que el nuevo contenido es Python válido
            try:
                ast.parse(new_content)
            except SyntaxError as e:
                return {"success": False, "error": f"Invalid Python syntax: {str(e)}"}
            
            # Escribir nuevo contenido
            with open(path, 'w', encoding='utf-8') as file:
                file.write(new_content)
            
            return result
            
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def search_in_file(self, file_path: str, pattern: str, regex: bool = False) -> List[Dict[str, Any]]:
        """Busca un patrón en un archivo"""
        path = Path(file_path)
        
        if not path.exists():
            return []
        
        matches = []
        
        try:
            with open(path, 'r', encoding='utf-8') as file:
                lines = file.readlines()
            
            for i, line in enumerate(lines, 1):
                if regex:
                    if re.search(pattern, line):
                        matches.append({
                            "line_number": i,
                            "line_content": line.strip(),
                            "match": True
                        })
                else:
                    if pattern in line:
                        matches.append({
                            "line_number": i,
                            "line_content": line.strip(),
                            "match": True
                        })
        
        except Exception as e:
            matches.append({"error": str(e)})
        
        return matches
    
    def replace_in_file(self, file_path: str, old_text: str, new_text: str, 
                       create_backup: bool = True) -> Dict[str, Any]:
        """Reemplaza texto en un archivo"""
        path = Path(file_path)
        
        if not path.exists():
            return {"success": False, "error": "File not found"}
        
        try:
            with open(path, 'r', encoding='utf-8') as file:
                content = file.read()
            
            new_content = content.replace(old_text, new_text)
            
            if new_content == content:
                return {"success": True, "changes": 0, "backup_path": None}
            
            # Usar modify_file para manejar backup y validación
            return self.modify_file(file_path, new_content, create_backup)
            
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def get_file_stats(self, file_path: str) -> Dict[str, Any]:
        """Obtiene estadísticas básicas de un archivo"""
        analysis = self.analyze_file(file_path)
        if not analysis:
            return {"error": "Could not analyze file"}
        
        return asdict(analysis)
    
    def list_backups(self, file_name: Optional[str] = None) -> List[Dict[str, str]]:
        """Lista backups disponibles"""
        backups = []
        
        for backup_file in self.backup_dir.iterdir():
            if backup_file.is_file():
                if file_name and not backup_file.name.startswith(Path(file_name).stem):
                    continue
                
                stats = backup_file.stat()
                backups.append({
                    "path": str(backup_file),
                    "name": backup_file.name,
                    "size": stats.st_size,
                    "created": datetime.fromtimestamp(stats.st_mtime).isoformat()
                })
        
        # Ordenar por fecha de creación (más reciente primero)
        backups.sort(key=lambda x: x["created"], reverse=True)
        return backups
    
    def restore_backup(self, backup_path: str, target_path: str) -> Dict[str, Any]:
        """Restaura un archivo desde un backup"""
        backup = Path(backup_path)
        target = Path(target_path)
        
        if not backup.exists():
            return {"success": False, "error": "Backup not found"}
        
        try:
            shutil.copy2(backup, target)
            return {"success": True, "restored_to": str(target)}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def diff_files(self, file1: str, file2: str) -> List[str]:
        """Compara dos archivos y retorna las diferencias"""
        try:
            with open(file1, 'r', encoding='utf-8') as f1:
                lines1 = f1.readlines()
            with open(file2, 'r', encoding='utf-8') as f2:
                lines2 = f2.readlines()
            
            import difflib
            diff = difflib.unified_diff(
                lines1, lines2,
                fromfile=file1,
                tofile=file2,
                lineterm=''
            )
            
            return list(diff)
            
        except Exception as e:
            return [f"Error: {str(e)}"]


# Función para usar en otros módulos
def get_code_scanner(base_path: str = ".") -> CodeScanner:
    """Retorna una instancia de CodeScanner"""
    return CodeScanner(base_path)


if __name__ == "__main__":
    # Test básico del módulo
    scanner = CodeScanner()
    
    # Test escaneo de directorio
    print("Escaneando directorio actual...")
    files = scanner.scan_directory()
    for file in files[:3]:  # Mostrar solo los primeros 3
        print(f"\nArchivo: {file.name}")
        print(f"Líneas: {file.lines}")
        print(f"Funciones: {file.functions}")
        print(f"Clases: {file.classes}")
    
    # Test análisis de archivo específico
    if files:
        test_file = files[0].path
        analysis = scanner.analyze_file(test_file)
        if analysis and not analysis.errors:
            print(f"\nAnálisis detallado de {analysis.name}:")
            print(f"Complejidad: {analysis.complexity_score}")
            print(f"Imports: {analysis.imports}")

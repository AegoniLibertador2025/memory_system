# AEGON Simple V2

Sistema de IA dividido en múltiples scripts con bot de Telegram integrado.

## Características

- **Memoria Persistente**: SQLite para conversaciones y JSON para conocimiento clave-valor
- **Auto Scanner**: Escaneo y análisis de archivos Python
- **Code Modifier**: Modificación de código con backups automáticos
- **Chat con IA**: Interfaz con OpenAI (GPT-3.5-turbo y GPT-4o)
- **Bot Telegram**: Acceso seguro con usuarios autorizados

## Instalación

1. Clonar el repositorio:
```bash
git clone <url-del-repo>
cd aegon-simple-v2
```

2. Crear entorno virtual:
```bash
python3 -m venv aegon_env
source aegon_env/bin/activate  # Linux/Mac
# o
aegon_env\Scripts\activate  # Windows
```

3. Instalar dependencias:
```bash
pip install -r requirements.txt
```

4. Configurar el bot:
- Editar `config.json` con tus API keys y usuarios autorizados
- O el bot creará un `config.json` por defecto en el primer arranque

## Uso

### Ejecutar el Bot
```bash
python main.py
```

### Comandos del Bot de Telegram

- `/start` - Inicia el bot
- `/help` - Muestra ayuda
- `/scan` - Escanea archivos .py en directorio actual
- `/analyze <archivo>` - Analiza un archivo Python específico
- `/modify <archivo> <código>` - Modifica un archivo (crea backup)
- `/memory <key>` - Lee valor de memoria
- `/memory <key> <value>` - Guarda en memoria
- `/chat <mensaje>` - Chat con IA
- Mensajes normales también activan el chat

## Estructura del Proyecto

```
aegon-simple-v2/
├── main.py                 # Punto de entrada
├── telegram_bot.py         # Bot de Telegram
├── memory_module.py        # Sistema de memoria
├── scanner_module.py       # Scanner y modificador de código
├── llm_module.py          # Interfaz con OpenAI
├── config.json            # Configuración
├── requirements.txt       # Dependencias
├── memory.db             # Base de datos SQLite
├── knowledge.json        # Almacén JSON
└── code_backups/        # Carpeta de backups
```

## Configuración

### config.json
```json
{
    "openai": {
        "api_key": "tu-api-key-aqui",
        "default_model": "gpt-3.5-turbo"
    },
    "telegram_bot": {
        "token": "tu-bot-token-aqui",
        "allowed_users": ["123456789"]
    }
}
```

### Variables de Entorno (Opcional)
```bash
export TELEGRAM_BOT_TOKEN="tu-token"
export OPENAI_API_KEY="tu-api-key"
```

## Seguridad

- Solo usuarios autorizados pueden usar el bot
- Backups automáticos antes de modificar archivos
- Logs completos en `aegon.log`

## Módulos

### memory_module.py
- Almacena conversaciones en SQLite
- Conocimiento clave-valor en JSON
- Funciones de backup y restauración

### scanner_module.py
- Escanea directorios por archivos .py
- Analiza imports, funciones y clases
- Modificación segura con backups

### llm_module.py
- Interfaz con OpenAI API
- Soporte para GPT-3.5-turbo y GPT-4o
- Gestión de historial de chat

### telegram_bot.py
- Bot de Telegram con handlers
- Autorización de usuarios
- Integración con todos los módulos

## Límites

- Cada script tiene menos de 300 líneas
- Solo modelos GPT-3.5-turbo y GPT-4o
- Interface solo por Telegram

## Logs

Los logs se guardan en:
- `aegon.log` - Archivo de log
- Consola - Output en tiempo real

## Troubleshooting

1. **Error de API**: Verificar API keys en config.json
2. **Usuario no autorizado**: Agregar user_id a allowed_users
3. **Error de permisos**: Verificar permisos de escritura en carpetas

## Licencia

MIT License

## Contribuciones

Bienvenidas mediante Pull Requests.
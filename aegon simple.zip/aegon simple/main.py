"""
Main entry point para AEGON Simple V2
Carga configuración y ejecuta el bot de Telegram
"""
import json
import sys
import logging
from pathlib import Path
from typing import Dict, Any

from telegram_bot import create_bot

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('aegon.log'),
        logging.StreamHandler(sys.stdout)
    ]
)

logger = logging.getLogger(__name__)


class AegonConfig:
    """Gestor de configuración para AEGON"""
    
    def __init__(self, config_file: str = "config.json"):
        self.config_file = Path(config_file)
        self.config: Dict[str, Any] = {}
        self.load_config()
    
    def load_config(self) -> None:
        """Carga configuración desde archivo JSON"""
        if not self.config_file.exists():
            self.create_default_config()
        
        try:
            with open(self.config_file, 'r') as f:
                self.config = json.load(f)
            logger.info(f"Configuración cargada desde {self.config_file}")
        except Exception as e:
            logger.error(f"Error cargando configuración: {e}")
            self.create_default_config()
    
    def create_default_config(self) -> None:
        """Crea archivo de configuración por defecto"""
        default_config = {
            "openai": {
                "api_key": "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",
                "default_model": "gpt-3.5-turbo"
            },
            "telegram_bot": {
                "token": "7772791418:AAGI1lhD7wNv3OP23mWpaZS_EhtsQ2V3w7U",
                "allowed_users": ["7526454163"]
            },
            "memory": {
                "db_path": "memory.db",
                "json_path": "knowledge.json"
            },
            "scanner": {
                "base_path": ".",
                "backup_dir": "code_backups"
            },
            "logging": {
                "level": "INFO",
                "file": "aegon.log"
            }
        }
        
        with open(self.config_file, 'w') as f:
            json.dump(default_config, f, indent=4)
        
        logger.info(f"Configuración por defecto creada en {self.config_file}")
        self.config = default_config
    
    def get(self, key_path: str, default: Any = None) -> Any:
        """Obtiene valor de configuración usando ruta con puntos"""
        keys = key_path.split('.')
        value = self.config
        
        for key in keys:
            if isinstance(value, dict) and key in value:
                value = value[key]
            else:
                return default
        
        return value
    
    def save_config(self) -> None:
        """Guarda la configuración actual"""
        try:
            with open(self.config_file, 'w') as f:
                json.dump(self.config, f, indent=4)
            logger.info("Configuración guardada")
        except Exception as e:
            logger.error(f"Error guardando configuración: {e}")
    
    def validate_config(self) -> bool:
        """Valida que la configuración tiene los campos necesarios"""
        required_fields = [
            "openai.api_key",
            "telegram_bot.token",
            "telegram_bot.allowed_users"
        ]
        
        for field in required_fields:
            if self.get(field) is None:
                logger.error(f"Campo requerido faltante: {field}")
                return False
        
        # Validar API keys (no vacías)
        if not self.get("openai.api_key").strip():
            logger.error("OpenAI API key está vacía")
            return False
        
        if not self.get("telegram_bot.token").strip():
            logger.error("Telegram bot token está vacío")
            return False
        
        # Validar usuarios autorizados
        allowed_users = self.get("telegram_bot.allowed_users", [])
        if not isinstance(allowed_users, list) or not allowed_users:
            logger.error("Lista de usuarios autorizados inválida")
            return False
        
        return True


def main():
    """Función principal"""
    try:
        logger.info("=" * 50)
        logger.info("Iniciando AEGON Simple V2")
        logger.info("=" * 50)
        
        # Cargar configuración
        config = AegonConfig("config.json")
        
        # Validar configuración
        if not config.validate_config():
            logger.error("Configuración inválida. Por favor revisa config.json")
            sys.exit(1)
        
        # Extraer configuración necesaria
        bot_token = config.get("telegram_bot.token")
        openai_api_key = config.get("openai.api_key")
        allowed_users = config.get("telegram_bot.allowed_users")
        default_model = config.get("openai.default_model", "gpt-3.5-turbo")
        
        # Crear y ejecutar bot
        logger.info("Creando bot de Telegram...")
        bot = create_bot(
            bot_token=bot_token,
            openai_api_key=openai_api_key,
            allowed_users=allowed_users,
            default_model=default_model
        )
        
        logger.info("Bot creado exitosamente")
        logger.info(f"Usuarios autorizados: {allowed_users}")
        logger.info(f"Modelo LLM por defecto: {default_model}")
        
        # Iniciar bot
        logger.info("Iniciando bot...")
        bot.run()
        
    except KeyboardInterrupt:
        logger.info("Bot detenido por usuario (Ctrl+C)")
        sys.exit(0)
    except Exception as e:
        logger.error(f"Error crítico: {e}")
        logger.exception("Detalles del error:")
        sys.exit(1)


if __name__ == "__main__":
    # Verificar Python version
    if sys.version_info < (3, 10):
        print("Este bot requiere Python 3.10 o superior")
        sys.exit(1)
    
    # Ejecutar main
    main()

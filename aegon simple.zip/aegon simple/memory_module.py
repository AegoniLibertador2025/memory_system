"""
Módulo de memoria simple persistente para AEGON Simple V2
Gestiona almacenamiento de conversaciones y conocimiento clave-valor
"""
import sqlite3
import json
from datetime import datetime
from typing import Optional, Dict, Any, List
from pathlib import Path


class MemoryManager:
    """Gestor de memoria simple con SQLite y JSON"""
    
    def __init__(self, db_path: str = "memory.db", json_path: str = "knowledge.json"):
        self.db_path = db_path
        self.json_path = json_path
        self._init_database()
        self._init_json()
    
    def _init_database(self) -> None:
        """Inicializa la base de datos SQLite para conversaciones"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS conversations (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id TEXT NOT NULL,
                    message TEXT NOT NULL,
                    response TEXT NOT NULL,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            """)
            conn.commit()
    
    def _init_json(self) -> None:
        """Inicializa archivo JSON para conocimiento clave-valor"""
        json_path = Path(self.json_path)
        if not json_path.exists():
            json_path.write_text("{}")
    
    def save_conversation(self, user_id: str, message: str, response: str) -> None:
        """Guarda una conversación en la base de datos"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO conversations (user_id, message, response)
                VALUES (?, ?, ?)
            """, (user_id, message, response))
            conn.commit()
    
    def get_recent_conversations(self, user_id: str, limit: int = 10) -> List[Dict[str, str]]:
        """Recupera las conversaciones más recientes de un usuario"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT message, response, timestamp 
                FROM conversations 
                WHERE user_id = ?
                ORDER BY timestamp DESC
                LIMIT ?
            """, (user_id, limit))
            
            results = cursor.fetchall()
            return [
                {
                    "message": row[0],
                    "response": row[1],
                    "timestamp": row[2]
                }
                for row in results
            ]
    
    def save_knowledge(self, key: str, value: Any) -> None:
        """Guarda conocimiento en formato clave-valor"""
        knowledge = self._load_knowledge()
        knowledge[key] = {
            "value": value,
            "timestamp": datetime.now().isoformat()
        }
        self._save_knowledge(knowledge)
    
    def get_knowledge(self, key: str) -> Optional[Any]:
        """Recupera conocimiento por clave"""
        knowledge = self._load_knowledge()
        if key in knowledge:
            return knowledge[key]["value"]
        return None
    
    def delete_knowledge(self, key: str) -> bool:
        """Elimina una entrada de conocimiento"""
        knowledge = self._load_knowledge()
        if key in knowledge:
            del knowledge[key]
            self._save_knowledge(knowledge)
            return True
        return False
    
    def list_knowledge_keys(self) -> List[str]:
        """Lista todas las claves de conocimiento disponibles"""
        knowledge = self._load_knowledge()
        return list(knowledge.keys())
    
    def get_all_knowledge(self) -> Dict[str, Any]:
        """Recupera todo el conocimiento almacenado"""
        return self._load_knowledge()
    
    def _load_knowledge(self) -> Dict[str, Any]:
        """Carga conocimiento desde JSON"""
        try:
            with open(self.json_path, 'r') as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            return {}
    
    def _save_knowledge(self, knowledge: Dict[str, Any]) -> None:
        """Guarda conocimiento en JSON"""
        with open(self.json_path, 'w') as f:
            json.dump(knowledge, f, indent=2)
    
    def search_conversations(self, user_id: str, query: str, limit: int = 10) -> List[Dict[str, str]]:
        """Busca en las conversaciones un término específico"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            search_pattern = f"%{query}%"
            cursor.execute("""
                SELECT message, response, timestamp 
                FROM conversations 
                WHERE user_id = ? AND (message LIKE ? OR response LIKE ?)
                ORDER BY timestamp DESC
                LIMIT ?
            """, (user_id, search_pattern, search_pattern, limit))
            
            results = cursor.fetchall()
            return [
                {
                    "message": row[0],
                    "response": row[1],
                    "timestamp": row[2]
                }
                for row in results
            ]
    
    def clear_conversations(self, user_id: str) -> None:
        """Elimina todas las conversaciones de un usuario"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM conversations WHERE user_id = ?", (user_id,))
            conn.commit()
    
    def clear_all_knowledge(self) -> None:
        """Elimina todo el conocimiento almacenado"""
        self._save_knowledge({})
    
    def export_conversations(self, user_id: str, output_file: str) -> None:
        """Exporta conversaciones a un archivo JSON"""
        conversations = self.get_recent_conversations(user_id, limit=1000)
        with open(output_file, 'w') as f:
            json.dump(conversations, f, indent=2)
    
    def import_conversations(self, input_file: str, user_id: str) -> int:
        """Importa conversaciones desde un archivo JSON"""
        with open(input_file, 'r') as f:
            conversations = json.load(f)
        
        count = 0
        for conv in conversations:
            self.save_conversation(user_id, conv["message"], conv["response"])
            count += 1
        
        return count
    
    def backup_memory(self, backup_dir: str = "backups") -> Dict[str, str]:
        """Crea backup de toda la memoria"""
        backup_path = Path(backup_dir)
        backup_path.mkdir(exist_ok=True)
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # Backup de base de datos
        db_backup = backup_path / f"memory_backup_{timestamp}.db"
        with sqlite3.connect(self.db_path) as source:
            with sqlite3.connect(str(db_backup)) as dest:
                source.backup(dest)
        
        # Backup de conocimiento
        json_backup = backup_path / f"knowledge_backup_{timestamp}.json"
        knowledge = self._load_knowledge()
        with open(json_backup, 'w') as f:
            json.dump(knowledge, f, indent=2)
        
        return {
            "database": str(db_backup),
            "knowledge": str(json_backup)
        }
    
    def restore_memory(self, db_backup: str, json_backup: str) -> None:
        """Restaura memoria desde backups"""
        # Restaurar base de datos
        with sqlite3.connect(db_backup) as source:
            with sqlite3.connect(self.db_path) as dest:
                source.backup(dest)
        
        # Restaurar conocimiento
        with open(json_backup, 'r') as f:
            knowledge = json.load(f)
        self._save_knowledge(knowledge)


# Función para usar en otros módulos
def get_memory_manager() -> MemoryManager:
    """Retorna una instancia de MemoryManager"""
    return MemoryManager()


if __name__ == "__main__":
    # Test básico del módulo
    memory = MemoryManager("test_memory.db", "test_knowledge.json")
    
    # Test de conversaciones
    memory.save_conversation("test_user", "Hola", "¡Hola! ¿Cómo estás?")
    recent = memory.get_recent_conversations("test_user")
    print(f"Conversaciones recientes: {recent}")
    
    # Test de conocimiento
    memory.save_knowledge("test_key", "test_value")
    value = memory.get_knowledge("test_key")
    print(f"Valor recuperado: {value}")
    
    # Test de backup
    backup_info = memory.backup_memory("test_backups")
    print(f"Backup creado: {backup_info}")
